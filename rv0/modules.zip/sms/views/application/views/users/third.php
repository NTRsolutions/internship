 <!DOCTYPE HTML>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link id="bootstrap-style" href="<?php echo base_url('bootstrap/css/bootstrap-3.3.7-dist/css/bootstrap.min.css');?>" rel="stylesheet">
<link id="base-style" href="<?php echo base_url('bootstrap/css/bootstrap-3.3.7-dist/css/style.css');?>" rel="stylesheet">
<script src="<?php echo base_url('bootstrap/css/bootstrap-3.3.7-dist/js/bootstrap.min.js');?>"></script>
<style>
@font-face
{
	font-family:glyphicons-halflings-regular;
	src:url(glyphicons-halflings-regular.ttf);
}
a{
  text-decoration:none;
}
active a:hover{
color:red;
}
div a:hover
{
  color:#cc0000;
  
}

a:visted{
color:#cc0000;
}

.right{
   float:right;
   margin-top:8px;
  
}
nav
{
    top:40px;
	position:fixed;
	
}
li:hover
{
	background:orange;
}
.pa{
   margin-left:-40px;
}
.rg{
   color:white;
}
</style>


</head>
<body>

<div class="right">
<i class="fa fa-lock" style="font-size:12px"></i><a href="#" style="margin:30px 20px 10px 0px">Login</a>
<i class="fa fa-sign-in" style="font-size:12px"></i><a href="#" style="margin:10px 60px 10px 0px">Register</a>
</div>
</div>

<nav class="navbar navbar-inverse">
<div class="w3-yellow">
  <div class="container-fluid">
    <div class="navbar-header">
      <ul class="nav navbar-nav ">
	  
      <li style="margin-left:80px"><a href="#">Home</a></li>
      <li ><a style="a:hover{color:#cc0000} href="#">Activity</a></li>
      <li><a href="#">Network</a></li>
      <li><a href="#">News</a></li>
	  <li><a href="#">Events</a></li>
      <li><a href="#">Gallery</a></li>
      <li><a href="form2.html">Store</a></li>
	  <li><a href="#">Contact us</a></li>
	  </ul>
	 
	  <ul class="nav navbar-nav navbar-right" >
	  <li ><a href="#"><span style="float:right" class="fa fa-shopping-cart" style="font-size:12px"></span>Cart</a></li>
	  
	 
	  </ul>
	 </div>
	
    </div>
	
  </div>
 </nav>
<h3 style="font-size:12px;margin:50px 0px 0px 110px;text-decoration:none">HOME/STORE/PRODUCT STORE/CUSTOMIZE/CHOOSE PRODUCT</h3>

 
    <div class="col-md-1"
      <div>
        
          <img src="e.jpg" style="width:100%;margin:20px 40px 0px 90px"><br />
		  <img src="bo.jpg" style="width:100%;margin:10px 20px 0px 90px"> <br />
		  <img src="nm.jpg" style="width:100%; margin:10px 20px 0px 90px"><br />
		  <img src="box.jpg" style="width:100%; margin:10px 20px 0px 90px">
		  
		  
         
        
      
    </div>
    <div class="col-md-3">
      <div class="thumbnail" style="margin:20px 20px 200px 90px">
       
          <img src="8.jpg" alt="Fjords" style="width:300px; height:300px">
      </div>
    </div>
	
	<div  style="margin-left:-100px">

	<p  class="pa" style="font-size:20px;text-decoration:none; margin:10px 0px 0px 50px"><strong>Standard Student Kits</strong></p> 
	<p class="pa"> Student134 | <span style="color:green">In Stock</span>
	<p  class="pa"style="font-size:10px"> 10 Reviews | Share | Add your review</p>
	 <h4> Total Items-6</h4>
	 <p class="pa"style="font-size:11px;word-spacing:5px">1)School Bag   2)Apsara Scholar Kit   3)Exam Clipboard </p>
	 <p class="pa" style="font-size:11px;word-spacing:5px"> 4)Notebook Single Line 5)Water Color Cake With Brush     6)Pencil Box</p>
	 <p class="pa"style="font-size:11px">Lorem Ipsum is simply dummy text of the printing and type setting Industry.Lorem Ipsum has been the</p>
	 <p class="pa" style="font-size:11px">industry's standard dummy text ever since the 1500s,when an unknown printer took a galley of type</p>
	 <p class="pa"style="font-size:11px">scrambled it to make a type specimen book.It has survived not only five countries but also the leap.</p>
	 <p style="font-size:15px">COST</p>
	 <p style="word-spacing:10px"><strong>₹499.99/-    </strong><strong><strike>₹555/-</strike></strong>    QUANTITY     <select>
  <option value=50>50</option>
  <option value="saab">40</option>
  <option value="mercedes">30</option>
  <option value="audi">20</option>
</select>  </p>
	 <p  button type="button" style="background-color:#2F4F4F" class="btn btn-primary active"><strong>ADD TO CART</strong></button></p>
	 <p button type="button" style="background-color:#FF4500" class="btn btn-primary disabled"><strong>CUSTOMIZE</strong></button></p>
	 <p><h3>Related Products<h3></p>
	
	 <div style ="width:100%">
		<div style ="float:left; width:60%">
		</div>
		<div style="float:right; margin:-400px 35px 0px 0px;height:300px;width:300px">
		<table><tr>
		<td style="background-color:#707070;font-size:11px;height:220px;width:220px"class="table-responsive" >
	<p class="rg"style="margin-left:20px">STANDARD PRODUCTS</p> <p class="rg" style="margin-left:20px">INDIVIDUAL PRODUCTS</p>
	<p class="rg"style="margin-left:25px" >Students</p><p class="rg"style="margin-left:25px">Alumni</p>
	<p class="rg"style="margin-left:25px">Faculty</p><p class="rg"style="margin-left:25px">Sports</p><p class="rg"style="margin-left:25px">Merchandise</p>
	<p class="rg"style="margin-left:25px">Accessories</p></td>
		</tr></table>
	
  </div>
  </div> 
   <table><tr><th>
	  <div style="margin-left:-280px"><figurecaption><img style="width:200px; height:200px;margin:20px 20px 20px 20px" class="img-responsive" src="pen.jpeg">Item Name</figurcaption></th>
	  <th><figurecaption><img style="width:200px; height:200px;margin:20px 10px 20px -18px" class="img-responsive" src="j.jpg">Item Name</figurcaption></th>
	 <th><figurcaption><img style="width:200px; height:200px;margin:20px 10px 20px 20px" class="img-responsive" src="book.jpg">Item Name</figurcaption></th>
	 <th><figurcaption><img style="width:200px; height:200px;margin:20px 10px 20px 20px" class="img-responsive" src="d.jpg">Item Name</figurcaption></div></th>
	  </tr>
	
	  </table>
	  <table><tr><th>
	  <div style="margin-left:250px"><figurcaption><img style="width:200px; height:200px;margin:20px 20px 20px 40px" class="img-responsive" src="pen.jpeg">Item Name</figurcaption></th>
	  <th><figurcaption><img style="width:200px; height:200px;margin:20px 10px 20px 20px" class="img-responsive" src="j.jpg">Item Name</figurcaption></th>
	 <th><figurcaption><img style="width:200px; height:200px;margin:20px 10px 20px 22px" class="img-responsive" src="book.jpg">Item Name</figurcaption></th>
	 <th> <figurcaption><img style="width:200px; height:200px;margin:20px 10px 20px 20px" class="img-responsive" src="d.jpg">Item Name</figurcaption></div></th>
	  </tr>
	  </table>
	<table><tr><th>
	  <div style="margin-left:250px"><figurcaption><img style="width:200px; height:200px;margin:20px 20px 20px 40px" class="img-responsive" src="pen.jpeg">Item Name</figurcaption></th>
	  <th><figurcaption><img style="width:200px; height:200px;margin:20px 10px 20px 20px" class="img-responsive" src="j.jpg">Item Name</figurcaption></th>
	 <th><figurcaption><img style="width:200px; height:200px;margin:20px 10px 20px 25px" class="img-responsive" src="book.jpg">Item Name </figurcaption></th>
	 <th><figurcaption> <img style="width:200px; height:200px;margin:20px 10px 20px 18px" class="img-responsive" src="d.jpg">Item Name</figurcaption></div></th>
	  </tr>
	  </table>
  




