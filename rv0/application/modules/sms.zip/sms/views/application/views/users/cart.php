<!DOCTYPE HTML>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
<link rel="stylesheet" href="bootstrap-3.3.7-dist/css/style.css">
<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.css">
<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
  <script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
<style>
@font-face
{
	font-family:glyphicons-halflings-regular;
	src:url(glyphicons-halflings-regular.ttf);
}
a{
  text-decoration:none;
}
active a:hover{
color:red;
}
div a:hover
{
  color:#cc0000;
  
}
.rg{ 
  color:white;
}
a:visted{
color:#cc0000;
}

.right{
   float:right;
   margin-top:10px;
  
}

nav
{
    top:40px;
	position:fixed;
	
	
}
li:hover
{
	background:orange;
}
   
nav div div ul li a:hover{
    background-color:#cc0000;
	color:#FFFF00;
}
nav div div ul li a:visited{
    background-color:#cc0000;
	color:#FFFF00;
}
.id{
   background-color:black;
   text-color:white;
   right:200px;
}
div div img:hover{
    background-color:#cc0000;
	color:#FFFF00;
}
 div p{
 align:100px 100px 100px 10px;
}	

</style>


</head>
<body>

<div class="right">
<i class="fa fa-lock" style="font-size:12px"></i><a href="#" style="margin:30px 20px 10px 5px">Login</a>
<i class="fa fa-sign-in" style="font-size:12px"></i><a href="#" style="margin:10px 60px 10px 5px">Register</a>
</div>
</div>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <ul class="nav navbar-nav ">
	  
      <li style="margin-left:80px"><a href="#" >Home</a></li>
      <li ><a href="#">Activity</a></li>
      <li><a href="#">Network</a></li>
      <li><a href="#">News</a></li>
	  <li><a href="#">Events</a></li>
      <li><a href="#">Gallery</a></li>
      <li><a href="second.html">Store</a></li>
	  <li><a href="#">Contact us</a></li>
	  </ul>
	 
	<ul class="nav navbar-nav navbar-right">
      <li style="margin-left:390px"><a href="#"><span class="fa fa-shopping-cart" style="margin-right:5px"></span>Cart</a></li>
    </ul>
	 </div>
	
  
	
  </div>
 </nav>
               <div class="row" style="margin-top: 70px">
                      <div class="col-sm-4 col-md-4 col-md-offset-1">
                              <div class="col-sm-6"><img src="img1.jpg" class="img-responsive" style="height: 200px;width: 200px"></div>
                      </div>
                      <div class="col-sm-6 col-md-2">
                          <table>
                          	<tr>
                          		<td>ProductName:ClassMate Notes</td>
                          	</tr>
                          	<tr>
                          		<td>Description:ClassMate Notes</td>
                          	</tr>
                          	<tr>
                          		<td>price:100</td>
                          	</tr>
                          </table>
                      </div>
                      <div class="col-md-3 col-md-offset-2">


             <table class="table-responsive"><tr>
		<td style="background-color:#707070;font-size:11px;text-color:white;height:250px;width:250px" >
	<p class="rg"style="margin-left:20px">STANDARD PRODUCTS</p> <p class="rg" style="margin-left:20px">INDIVIDUAL PRODUCTS</p>
	<p class="rg"style="margin-left:25px" >Students</p><p class="rg"style="margin-left:25px">Alumni</p>
	<p class="rg"style="margin-left:25px">Faculty</p><p class="rg"style="margin-left:25px">Sports</p><p class="rg"style="margin-left:25px">Merchandise</p>
	<p class="rg"style="margin-left:25px">Accessories</p></td></tr>
		</tr></table>
                      </div>
               </div>

               <div class="row" style="margin-top:10px">
                      <div class=" col-sm-6 col-sm-4 col-md-4 col-md-offset-1">
                              <div class="col-sm-6"><img src="img4.jpg" class="img-responsive" style="height: 200px;width: 200px"></div>
                      </div>
                      <div class=" col-sm-6 col-md-2">
                          <table>
                          	<tr>
                          		<td>ProductName:ClassMate Notes</td>
                          	</tr>
                          	<tr>
                          		<td>Description:ClassMate Notes</td>
                          	</tr>
                          	<tr>
                          		<td>price:300</td>
                          	</tr>
                          </table>
                      </div>
               </div>
               <div class="row">

                    <div class="col-md-5 col-md-offset-3">

                              <p><strong>Total Amount:400</strong></p>
                    </div>
               </div>
	 
	 
	 
</body>
</html>