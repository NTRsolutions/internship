<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body>
<h4>Thanks for registration<br>click <a href="signin">here</a> to signin</h4>

</body>
</html>
