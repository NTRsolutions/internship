<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Files extends CI_Controller {

	public function index()
	{
		$data['filenames']=get_dir_file_info('Files/',TRUE);

		print_r($data);
		$this->load->view('file_main',$data);
	}
	public function create_class($path)
	{		
		$i=1;
		$dir=$path.'/class'.$i;
		while(is_dir($dir))
		{
			$i++;
			$dir=$path.'/class'.$i;
		}
		mkdir($path.'/class'.$i,0755,TRUE);

		$data['filenames']=get_dir_file_info('Files/',TRUE);
		$this->load->view('file_main',$data);
	}
	public function create_section($path,$class)
	{		
		$i=1;
		$dir=$path.'/'.$class.'/'.'section'.$i;
		
		while(is_dir($dir))
		{
			$i++;
			$dir=$path.'/'.$class.'/'.'section'.$i;
		}
		mkdir($path.'/'.$class.'/'.'section'.$i,0755,TRUE);

		$data['filenames']=get_dir_file_info('Files/'.$class,TRUE);
		
		$data['parent']=$class;
		$this->load->view('file_sub',$data);
	}


	public function open($parent,$filename)
	{

		$data['filenames']=get_dir_file_info($parent.'/'.$filename,TRUE);

		$data['parent']=$filename;

		$this->load->view('file_sub',$data);
	}
	public function open_section($main,$class,$section)
	{

		$data['filenames']=get_dir_file_info($main.'/'.$class.'/'.$section,TRUE);
		//echo $main.'/'.$class.'/'.$section;
		$data['path']=$main.'/'.$class.'/'.$section;
		//print_r($data);
		$this->load->view('file_csv',$data);
	}
}
?>