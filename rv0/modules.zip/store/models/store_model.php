<?php
class Store_model extends CI_Model {

	function __construct()
        {
             parent::__construct();
             $this->load->database();
        }
        function getproducts()
        {
        	
        	$data=$this->db->get('whd_products');
        	$dataa=$data->result();
        	return $dataa;
        	

        }
        function getcategory($ctg)
        {

            $this->db->where('p_category',$ctg);
            $data=$this->db->get('whd_products');
            $dataa=$data->result();
            return $dataa;
        }
        function return_product($pid)
        {
            $this->db->where('pid', $pid);
            $data=$this->db->get('whd_products');
            return $data->result();
        }
        function insert_cartdetails($data)
        {
           
            $this->db->where('session_id',$data['session_id']);
            $this->db->where('user_id',$data['user_id']);
            $this->db->where('pid',$data['pid']);
            $p=$this->db->get('whd_cart');
            $p=$p->result();
           
            

            if(count($p)!=0)
            {
                $q=$data['quantity']+$p[0]->quantity;
                $this->db->set('quantity', $q);
                $this->db->where('session_id',$data['session_id']);
                $this->db->where('user_id',$data['user_id']);
                $this->db->where('pid',$data['pid']);
                $this->db->update('whd_cart');

                
            }
            else
            $this->db->insert('whd_cart',$data);
        }
        function getcart_products($cart_products)
        {
            $pids=array();
            /*foreach ($cart_products as $key => $value) {
                $pids[]=$value['pid'];
            }*/
            foreach ($cart_products as $key => $value) {
                $pids[]=$value->pid;
            }
           $this->db->where_in('pid',$pids);
            $data = $this->db->get('whd_products');
            return $data->result();

        }
        
        function check($data)
         {
            /*$f=0;
            $query=$this->db->get("users");
            $details=$query->result();
            foreach($details as $key => $value)
            {
                //echo $data['pwd'];//$value->username."  ".$data['username'].$value->pwd;
                if($data['username']==$value->username && $data['pwd']==$value->pwd)
                {
                    $f=1;
                    break;
                }
            }
            if($f==1)
            {
                echo '<h4>Login successfully.....</h4>'.'<a href="'.base_url().'sign_control">logout</a>';
            }
            else
                $this->load->view("signin");
            */
            $this->db->where("username",$data['username']);
            $this->db->where("pwd",$data['pwd']);
            $rec=$this->db->get("users_details");
            if($rec->num_rows()>0)
            {
                return true;
            }
            else
                return false;

    }
    function remove_from_cart($user_id,$session_id,$pid)
    {
        if($user_id!='')
        {
            $this->db->where('user_id', $user_id);
           $this->db->where('pid', $pid);
           $this->db->delete('whd_cart');
        }
        else
        {
           $this->db->where('session_id', $session_id);
           $this->db->where('pid', $pid);
           $this->db->delete('whd_cart');
        }
    }
    function getcart($session_id,$user_id)
    {
        
        if($user_id!='')
        {

            
            $this->db->select('pid','quantity');
            $this->db->where('user_id',$user_id);
            $data=$this->db->get('whd_cart');
            return $data->result();
        }
        else
        {   

            $this->db->where('session_id',$session_id);
            $data=$this->db->get('whd_cart');

            return $data->result();
        }
          
    }
    function getstandardproduct()
    {
        $this->db->where('p_category','Standard_Products');
        $data=$this->db->get('whd_products');
        $data=$data->result();
        return $data[0]->pid;
    }

}
?>
