<?php
class Store extends CI_Controller {
	public function __construct()
        {
                parent::__construct();
                $this->load->model('store_model');  
                $this->load->library("form_validation");
                $this->load->library('session');
                $this->load->helper('form','url');
                $this->load->helper('cookie');


                                  
        }
        function index()
        {
            $data=array();

           $layout_session = $this->session->userdata('logged_in');
            if(!empty(get_cookie('rightlink_cart')))
            {
                 
               /* $cart_products=$this->session->userdata('cart_products');
                $data['product']=$this->store_model->getproducts();
                $total_quantity=0;
                foreach ($cart_products as $key => $value) {
                        $total_quantity+=$value['quantity'];
                        # code...
                    }    
            
                $data['no_products']=$total_quantity;
                //echo "hi";
                $session_id = $this->session->userdata('session_id');
               // echo $session_id;exit;

                if( isset( $_COOKIE['rightlink_cart']  ) )
                {
                     var_dump($_COOKIE );
                     exit; 
                }
                else
                {
                     echo 'no cookie for you!';
                     exit;
                } 


               // print_r($data);
                //$this->load->view('store_list',$data);
                $data['theme_body'] = $this->load->view('store_list',$data);
                $this->load->view('theme/gj/inner_layout', $data);
            }
            else
            {
                 $cart_products=array();
           		 $this->session->set_userdata('cart_products', $cart_products);
                    //echo 'hello';
                $data['product']=$this->store_model->getproducts();
                $data['no_products']=0;

                $session_id = $this->session->userdata('session_id');
               
                if( isset( $_COOKIE['rightlink_cart']  ) )
                {
                     var_dump($_COOKIE );
                     exit; 
                }
                else
                {
                     echo 'no cookie for you!';
                     exit;
                } 

               
               // print_r($data);
                //$this->load->view('store_list',$data);
                */
                //$layout_session = $this->session->userdata('logged_in');
                $total_quantity=0;
               if($layout_session['user']['id']!='')
               {
                $session_id=get_cookie('rightlink_cart');
                $p=$this->store_model->getcart($session_id,$layout_session['user']['id']);
                foreach ($p as $key => $value) 
                {
                    $total_quantity+=$value->quantity;
                }
                 $data['no_products']=$total_quantity;
               // echo 'hi';
                
               }
               else
               {
                    
                    $session_id=get_cookie('rightlink_cart');
                    $p=$this->store_model->getcart($session_id,'');
                    foreach ($p as $key => $value) 
                    {
                        $total_quantity+=$value->quantity;
                    }
                    $data['no_products']=$total_quantity;   
                    
               }

               $data['product']=$this->store_model->getproducts();
                
            }
            else
            {
                $session_id = $this->session->userdata('session_id');
                $cookie = array(
                  'name'   => 'rightlink_cart',
                  'value'  => $session_id,
                   'expire' => '86500',
                );
                $this->input->set_cookie($cookie);
               
               $total_quantity=0;
               if($layout_session['user']['id']!='')
               {
                $p=$this->store_model->getcart('',$layout_session['user']['id']);
                foreach ($p as $key => $value) 
                {
                    $total_quantity+=$value->quantity;
                }
                 $data['no_products']=$total_quantity;
               // echo 'hi';
                
               }
                else
                {
                $data['product']=$this->store_model->getproducts();
                $data['no_products']=0;
                }
            }
            
           
            $data['theme_body'] = $this->load->view('store_list',$data);
            $this->load->view('theme/gj/inner_layout', $data);
            
        }
       /* function verify_login()
        {

               
                $this->form_validation->set_rules('username','username','required');
                $this->form_validation->set_rules('pwd','pwd','required');
                if($this->form_validation->run())
                {
                     $uname=$this->input->post('username');
                     $pwd=$this->input->post('pwd');
                     $data=array('username'=>$uname,'pwd'=>$pwd);
                     if($this->store_model->check($data))
                     {
                        $session_data=array("username"=>$uname);
                        $this->session->set_userdata('ci_session',$session_data);
                        $userData['first_name']=$uname;
                        $data['userData'] = $userData;
                        $cart_products=array();
				           
				            $this->session->set_userdata('cart_products', $cart_products);
				                    //echo 'hello';
				            $data['product']=$this->store_model->getproducts();
				            $data['no_products']=0;
				            $this->load->view('store_list',$data);
                     }
                     else
                     {
                     	//echo 'hi';
                        $this->session->set_flashdata("error","invalid username and password");
                        redirect(base_url().'users/user_control/signin');
                     }
                     
                }
                else
                {
                    $this->login();
                }

               
        }*/

        function store_product($pid)
        {

            $session_id = $this->session->userdata('session_id');
        $cookie = array(
                  'name'   => 'rightlink_cart',
                  'value'  => $session_id,
                   'expire' => '86500',
                );
                $this->input->set_cookie($cookie);

             $d['data']=$this->store_model->return_product($pid);
              $layout_session = $this->session->userdata('logged_in');
            if(!empty(get_cookie('rightlink_cart')))
            {
            $total_quantity=0;
               if($layout_session['user']['id']!='')
               {
                $session_id=get_cookie('rightlink_cart');
                $p=$this->store_model->getcart($session_id,$layout_session['user']['id']);
                foreach ($p as $key => $value) 
                {
                    $total_quantity+=$value->quantity;
                }
                 $d['no_products']=$total_quantity;
               // echo 'hi';
                
               }
               else
               {
                    
                    $session_id=get_cookie('rightlink_cart');
                    $p=$this->store_model->getcart($session_id,'');
                    foreach ($p as $key => $value) 
                    {
                        $total_quantity+=$value->quantity;
                    }
                    $d['no_products']=$total_quantity;   
                    
               }

               
                
            }
            else
            {
               
               $total_quantity=0;
               if($layout_session['user']['id']!='')
               {
                $p=$this->store_model->getcart('',$layout_session['user']['id']);
                foreach ($p as $key => $value) 
                {
                    $total_quantity+=$value->quantity;
                }
                 $d['no_products']=$total_quantity;
               // echo 'hi';
                
               }
                else
                {
                
                $d['no_products']=0;
                }
            }

            
            
            $data['theme_body']=$this->load->view('store_product',$d);
            $this->load->view('theme/gj/inner_layout', $data);
        }
	
    public function add_to_cart() {
        $layout_session = $this->session->userdata('logged_in');
        $session_id = $this->session->userdata('session_id');
       
        $flag=0;
        

        // Whenever a user adds an item to their cart, pull out any they already have in there
        $product_id=$_POST['pid'];
        $quantity=$_POST['quantity'];

        $cart_products = $this->session->userdata('cart_products');

        // Add the new item
        /*foreach ($cart_products as $key => $value) {
            if($value['pid']==$product_id)
            {

                $cart_products[$key]['quantity']+=$quantity;
                $flag=1;       
            }

        }
        if($flag==0)
        {
            $cart_products[] = array('pid'=>$product_id,'quantity'=>$quantity);
        }*/
        
        if($layout_session['user']['id']!='')
        {
                $cart=array("session_id"=>$session_id ,"user_id"=>$layout_session['user']['id'],"pid"=>$product_id,"quantity"=>$quantity);
               // print_r($cart);
                    $this->store_model->insert_cartdetails($cart);
        }
        else
        {
             $cart=array("session_id"=>$session_id ,"user_id"=>'',"pid"=>$product_id,"quantity"=>$quantity);
             
                    $this->store_model->insert_cartdetails($cart);

        }
        //print_r($cart_products);exit;
            // And put it back into the session
            //$this->session->unset_userdata('cart_products');
            //$this->session->set_userdata('cart_products', $cart_products);
        
      /*   $total_quantity=0;
        foreach ($cart_products as $key => $value) {
                $total_quantity+=$value['quantity'];
                # code...
            }    
        echo $total_quantity;
        $this->load->helper('cookie');
        set_cookie('rightlink_cart',$session_id,'86500');


                $cookie = array(
          'name'   => 'rightlink_cart',
          'value'  => $session_id,
           'expire' => '86500',
        );
        $this->input->set_cookie($cookie);

        if(isset(get_cookie('rightlink_cart'))){ // check cookie value
          echo "success"; // replace with your code
        }
        else{
          echo "failed"; // replace with your code
        }*/
        
        $data= array();

                
        if(!empty(get_cookie('rightlink_cart')))
        {
        $layout_session = $this->session->userdata('logged_in');
        $session_id = $this->session->userdata('session_id');
         $total_quantity=0;
               if($layout_session['user']['id']!='')
               {
                    $session_id=get_cookie('rightlink_cart');
                    $p=$this->store_model->getcart($session_id,$layout_session['user']['id']);
                    foreach ($p as $key => $value) 
                    {
                        $total_quantity+=$value->quantity;
                    }
                     $data['no_products']=$total_quantity;
                   // echo 'hi';
                    //print_r($data);
               }
               else
               {
                    
                    $session_id=get_cookie('rightlink_cart');
                    $p=$this->store_model->getcart($session_id,'');
                    foreach ($p as $key => $value) 
                    {
                        $total_quantity+=$value->quantity;
                    }
                    $data['no_products']=$total_quantity; 

                    //print_r($data);
                    //echo 'hi';
               }

               
           }     //echo 'h
            else
            {
                
               $total_quantity=0;
               if($layout_session['user']['id']!='')
               {
                $p=$this->store_model->getcart('',$layout_session['user']['id']);
                foreach ($p as $key => $value) 
                {
                    $total_quantity+=$value->quantity;
                }
                 $data['no_products']=$total_quantity;
               // echo 'hi';
                //print_r($data);
               }
                else
                {
                //$data['product']=$this->store_model->getproducts();
                $data['no_products']=0;
                }
            }

            echo $data['no_products'];

            exit;
       
        
    }
    function cart_details()
    {
        /*$cart_products = $this->session->userdata('cart_products');
        if(!empty($cart_products))
        {
            $d['data']=$this->store_model->getcart_products($cart_products);
            $session_products=$this->session->userdata('cart_products');
            $total_quantity=0;
            foreach ($cart_products as $key => $value) {
                    $total_quantity+=$value['quantity'];
                    # code...
                }    
            
             $d['no_products']=$total_quantity;
             $d['quantity']=$cart_products;
            //print_r($d);
            $data['theme_body']=$this->load->view('store_cartdetails',$d);
             $this->load->view('theme/gj/inner_layout', $data);
        }
        else
        {
            $d['data']=array();
            $d['no_products']=0; 
            $data['theme_body']=$this->load->view('store_emptycartdetails',$d);
             $this->load->view('theme/gj/inner_layout', $data);
        }*/
        $f=0;
        $session_id = $this->session->userdata('session_id');
        $total_quantity=0;
        $layout_session = $this->session->userdata('logged_in');
        $data=array();
            if(!empty(get_cookie('rightlink_cart')))
            {
                if($layout_session['user']['id']!='')
                {
                    $session_id=get_cookie('rightlink_cart');
                    $p=$this->store_model->getcart($session_id,$layout_session['user']['id']);
                    foreach ($p as $key => $value) {
                        $total_quantity+=$value->quantity;

                    }
                    $data['no_products']=$total_quantity;
                    if($total_quantity==0)
                    $f=1;
                   // echo 'hi';
                    else
                    {
                        $data['data']=$this->store_model->getcart_products($p);
                        $data['quantity']=$p;
                        $data['theme_body']=$this->load->view('store_cartdetails',$data);
                        $this->load->view('theme/gj/inner_layout', $data);
                    }

               }
               else
               {
                    $session_id=get_cookie('rightlink_cart');
                    $p=$this->store_model->getcart($session_id,'');
                    foreach ($p as $key => $value) {
                    $total_quantity+=$value->quantity;
                    }
                    $data['no_products']=$total_quantity;
                    if($total_quantity==0)
                    $f=1;
                    else
                    {
                        $data['data']=$this->store_model->getcart_products($p);

                        $data['quantity']=$p;

                        $data['theme_body']=$this->load->view('store_cartdetails',$data);
                        $this->load->view('theme/gj/inner_layout', $data);
                    }
                    
               }

               
                
            }
            else
            {

               $data['data']=array();
            $data['no_products']=0; 
            $data['theme_body']=$this->load->view('store_emptycartdetails',$data);
            print_r($data);
             $this->load->view('theme/gj/inner_layout', $data);


            }
            if($f==1)
            {

               $data['data']=array();
            $data['no_products']=0; 
            $data['theme_body']=$this->load->view('store_emptycartdetails',$data);
            
             $this->load->view('theme/gj/inner_layout', $data);   
            }
             //$data['theme_body'] = $this->load->view('store_list',$data);
            
            //$this->load->view('theme/gj/inner_layout', $data);
            

            
    }
    function remove_from_cart($pid)
    {
      
        $session_id=get_cookie('rightlink_cart');
        $layout_session = $this->session->userdata('logged_in');
        if($layout_session['user']['id']!='')
        {
        $this->store_model->remove_from_cart($layout_session['user']['id'],'',$pid);
        }
        else
        {
                $this->store_model->remove_from_cart('',$session_id,$pid);
        }
        $this->cart_details();


        
    }
    function logoimage()
    {
        
        //echo 'hijdjlfjljlkfjglfjgljdfljgldjfljdl';
    //set preferences
            /*  $config['upload_path']          = './customize/';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;

    //load upload class library
        $this->load->library('upload', $config);

        //$this->upload->do_upload('filename') will upload selected file to destiny folder
        if (!$this->upload->do_upload('imgdb'))
        {
            // case - failure
            $upload_error = array('error' => $this->upload->display_errors());
            echo $this->upload->display_errors();
            //$this->load->view('some_view', $upload_error);
        }
        else
        {
            // case - success
            $this->User_model->customimg_update();
            echo 'Success';
        }*/
        define('UPLOAD_DIR', './uploads/store/customize/');
    $img = $_POST['imgdb'];
    
    $img = str_replace('data:image/png;base64,', '', $img);
    $img = str_replace(' ', '+', $img);
    $data = base64_decode($img);
    $file = UPLOAD_DIR . uniqid() . '.png';
    $success = file_put_contents($file, $data);
    
    print $success ? $file : 'Unable to save the file.';
       
    }
    function pop_window($img)
    {
        $d['img']=$img;
        $this->load->view('pop_window',$d);
    }
function standard_products()
{
    $d=$this->store_model->getstandardproduct();
    $this->store_product($d);
}

}

?>
