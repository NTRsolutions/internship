<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Email extends CI_Controller {

	function sendemail()
	{
		$config = Array(
    'protocol' => 'smtp',
    'smtp_host' => 'ssl://smtp.googlemail.com',
    'smtp_port' => 465,
    'smtp_user' => 'ganesh.kanthiwar@gmail.com',
    'smtp_pass' => 'gani.123',
    'mailtype'  => 'html', 
    'charset'   => 'iso-8859-1'
);
$this->load->library('email', $config);
$this->email->set_newline("\r\n");

		$this->email->from('ganesh.kanthiwar@gmail.com', 'Ganesh');
		$this->email->to('policevenkatesh88@gmail.com');

		$this->email->subject('Email Test');
		$this->email->message('Testing the email class.');

		echo $this->email->send();
		echo $this->email->print_debugger(array('headers'));
	}
}
