

<h3>Your file was not uploaded!</h3>
<?php echo $msg;?>

<p><?php echo anchor('http://localhost/new/rv0/collections/'.$url, 'Upload Another File!'); ?></p>

