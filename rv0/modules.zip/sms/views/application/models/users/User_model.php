<?php
class User_model extends CI_Model {

	function __construct()
        {
             parent::__construct();
             $this->load->database();
        }
        function getproducts()
        {
        	$this->db->select('p_name, r_price,img');
        	$data=$this->db->get('products');
        	$dataa=$data->result();
        	return $dataa;
        	

        }
        function return_product($p_name)
        {
            $this->db->where('p_name', $p_name);
            $data=$this->db->get('products');
            return $data->result();
        }
        function getcart_products($p_names)
        {
           $this->db->where_in('p_name',$p_names);
            $data = $this->db->get('products');
            return $data->result();
        }
        function customimg_update(){

        }
        function check($data)
         {
            /*$f=0;
            $query=$this->db->get("users");
            $details=$query->result();
            foreach($details as $key => $value)
            {
                //echo $data['pwd'];//$value->username."  ".$data['username'].$value->pwd;
                if($data['username']==$value->username && $data['pwd']==$value->pwd)
                {
                    $f=1;
                    break;
                }
            }
            if($f==1)
            {
                echo '<h4>Login successfully.....</h4>'.'<a href="'.base_url().'sign_control">logout</a>';
            }
            else
                $this->load->view("signin");
            */
            $this->db->where("username",$data['username']);
            $this->db->where("pwd",$data['pwd']);
            $rec=$this->db->get("users_details");
            if($rec->num_rows()>0)
            {
                return true;
            }
            else
                return false;

    }
}
?>
