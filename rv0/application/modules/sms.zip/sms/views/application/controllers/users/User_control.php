<?php
class User_control extends CI_Controller {
	public function __construct()
        {
                parent::__construct();
                $this->load->model('users/user_model');  
                 $this->load->library("form_validation");
                 $this->load->helper('form','url');
                $this->load->model('user');//via google user data 
             $this->load->library('facebook2'); 
                         
        }
        function index()
        {
            if(!empty($this->session->userdata('cart_products')))
            {
                 
                $cart_products=$this->session->userdata('cart_products');
                $data['product']=$this->user_model->getproducts();
                $data['no_products']=count($cart_products);
               // print_r($data);
                $this->load->view('users/home',$data);
            }
            else
            {
                 $cart_products=array();
            $this->session->set_userdata('cart_products', $cart_products);
                    //echo 'hello';
                $data['product']=$this->user_model->getproducts();
                $data['no_products']=0;
               // print_r($data);
                $this->load->view('users/home',$data);
            }

        }


        function login()
        {
        		  $userData = array();
                 $data=array();
		        $userDta=array();
		        $i=0;
		        // Check if user is logged in
		        if($this->facebook2->is_authenticated()){
		            $i=1;
		            // Get user facebook profile details
		            $userProfile = $this->facebook2->request('get', '/me?fields=id,first_name,last_name,email,gender,locale,picture');

		            // Preparing data for database insertion
		            $userData['oauth_provider'] = 'facebook';
		            $userData['oauth_uid'] = $userProfile['id'];
		            $userData['first_name'] = $userProfile['first_name'];
		            $userData['last_name'] = $userProfile['last_name'];
		           //$userData['email'] = $userProfile['email'];
		            //$userData['gender'] = $userProfile['gender'];
		            $userData['locale'] = $userProfile['locale'];
		            $userData['profile_url'] = 'https://www.facebook.com/'.$userProfile['id'];
		            $userData['picture_url'] = $userProfile['picture']['data']['url'];
		            
		            // Insert or update user data
		            $userID = $this->user->checkUser($userData);
		            
		            // Check user data insert or update status
		            if(!empty($userID)){
		                $data['userData'] = $userData;
		                $this->session->set_userdata('userData',$userData);
		                
		            } else {
		               $data['userData'] = array();
		            }
		            
		            // Get logout URL
		            $data['logoutUrl'] = $this->facebook2->logout_url();


		           $cart_products=array();
            $this->session->set_userdata('cart_products', $cart_products);
                    //echo 'hello';
                $data['product']=$this->user_model->getproducts();
                $data['no_products']=0;


		             $this->load->view('/users/home',$data);
		        }else{
		            $fbuser = '';
		            
		            // Get login URL
		            $data['authUrl'] =  $this->facebook2->login_url();
		        }
		        //echo $data['authUrl'];
		        // Load login & profile view
		        if($i==0)
		        {
		                include_once APPPATH."libraries/google-api-php-client/Google_Client.php";
		                include_once APPPATH."libraries/google-api-php-client/contrib/Google_Oauth2Service.php";
		                
		                // Google Project API Credentials
		               

		                  $clientId = '217170084392-mm5c75gfmpvuh6lomh1t4no4vrol4pb4.apps.googleusercontent.com';
		                        $clientSecret = 'OijkuHbrchGvVYnaXt37QZl2';
		                        $redirectUrl = base_url() . 'users/user_control/login';
		                // Google Client Configuration
		                $gClient = new Google_Client();
		                $gClient->setApplicationName('Login to website');
		                $gClient->setClientId($clientId);
		                $gClient->setClientSecret($clientSecret);
		                $gClient->setRedirectUri($redirectUrl);
		                $google_oauthV2 = new Google_Oauth2Service($gClient);

		                if (isset($_REQUEST['code'])) {
		                    $gClient->authenticate();
		                    $this->session->set_userdata('token', $gClient->getAccessToken());
		                    redirect($redirectUrl);
		                }

		                $token = $this->session->userdata('token');
		                if (!empty($token)) {
		                    $gClient->setAccessToken($token);
		                }

		                if ($gClient->getAccessToken()) {
		                    $userP = $google_oauthV2->userinfo->get();
		                    // Preparing data for database insertion
		                    $userData['oauth_provider'] = 'google';
		                    $userData['oauth_uid'] = $userP['id'];
		                    $userData['first_name'] = $userP['given_name'];
		                    $userData['last_name'] = $userP['family_name'];
		                    $userData['email'] = $userP['email'];
		                    
		                    $userData['locale'] = $userP['locale'];
		                   // $userData['profile_url'] = $userProfile['link'];
		                    $userData['picture_url'] = $userP['picture'];
		                    // Insert or update user data
		                    $uID = $this->user->checkUser($userData);
		                    if(!empty($uID)){
		                        $data['userData'] = $userData;
		                        $this->session->set_userdata('userData',$userData);

		                        $cart_products=array();
					            $this->session->set_userdata('cart_products', $cart_products);
					                    //echo 'hello';
					                $data['product']=$this->user_model->getproducts();
					                $data['no_products']=0;

		                        $this->load->view('users/home',$data);
		                    } else {
		                       $data['userData'] = array();
		                    }
		                } else {
		                    $data['AuthUrl'] = $gClient->createAuthUrl();

		                    $this->load->view('/users/signin',$data);
		                    
		                }
		            }
        }
        function verify_login()
        {

               
                $this->form_validation->set_rules('username','username','required');
                $this->form_validation->set_rules('pwd','pwd','required');
                if($this->form_validation->run())
                {
                     $uname=$this->input->post('username');
                     $pwd=$this->input->post('pwd');
                     $data=array('username'=>$uname,'pwd'=>$pwd);
                     if($this->user_model->check($data))
                     {
                        $session_data=array("username"=>$uname);
                        $this->session->set_userdata('ci_session',$session_data);
                        $userData['first_name']=$uname;
                        $data['userData'] = $userData;
                        $cart_products=array();
				           
				            $this->session->set_userdata('cart_products', $cart_products);
				                    //echo 'hello';
				            $data['product']=$this->user_model->getproducts();
				            $data['no_products']=0;
				            $this->load->view('/users/home',$data);
                     }
                     else
                     {
                     	echo 'hi';
                        $this->session->set_flashdata("error","invalid username and password");
                        redirect(base_url().'users/user_control/signin');
                     }
                     
                }
                else
                {
                    $this->login();
                }

               
        }

        function store($p_name)
        {
            $d['data']=$this->user_model->return_product($p_name);
            $session_products=$this->session->userdata('cart_products');
            $d['no_products']=count($session_products);
        	$this->load->view('users/second',$d);
        }
		


}
?>
