<?php
class Product extends CI_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->model("product_model");
        $this->load->helper(array('form', 'url'));
        
    }
    public function index()
    {
         $this->load->view("product_index");
    }
   public function view_product()
    {
        $d['data']=$this->product_model->getproduct();
        $this->load->view("product_viewproduct",$d);

    }
    public function addproduct()
    {
        
        $this->load->view("product_addproduct");

    }
    public function search()
    {

         $search=  $this->input->post('search');
        
          $d['data'] = $this->product_model->getproducts_onkey($search);
          
          $this->load->view("product_searchproduct",$d);

    }
    public function delete($pid)
    {
         $this->product_model->delete_record($pid);
         $d['data']=$this->product_model->getproduct();
        $this->load->view("product_viewproduct",$d);

    }
    public function edit($pid)
    {
         $d['data']=$this->product_model->return_update_record($pid);
         $this->load->view("product_editproduct",$d);

    }
    public function do_update($pid)
    {
                $pid=$this->input->post('pid');
                $p_name=$this->input->post('p_name');
                $status=$this->input->post('status');
                $category=$this->input->post('Category');
                $discription=$this->input->post('discription');
                $o_price=$this->input->post('o_price');
                $r_price=$this->input->post('r_price');
                $s_price=$this->input->post('s_price');
                $c_price=$this->input->post('c_price');
                $srp=$this->input->post('srp');
        
                $img="";





                //img upload start
                $config['upload_path']          = './uploads/store';
                $config['allowed_types']        = 'gif|jpg|png|jpeg';
                //$config['max_size']             = 100;
                //$config['max_width']            = 1024;
                //$config['max_height']           = 768;

                $this->load->library('upload', $config);
                $d=array();
//&& $this->upload->do_upload('rightview') && $this->upload->do_upload('leftview') && $this->upload->do_upload('topview') && $this->upload->do_upload('bottomview')

                if (  $this->upload->do_upload('img'))
                {
                    
                        
                        $imgdetails = array('upload_data' => $this->upload->data());
                        $img=$this->upload->data('file_name');

                         $img=$img['file_name'];
                        $data=array('p_name' => $p_name,'status' => $status,'discription'=> $discription,'o_price'=>$o_price,'r_price'=>$r_price,'s_price'=>$s_price,'c_price'=>$c_price,'srp'=>$srp,'img'=>$img,'pid'=>$pid);
                        $d["data"]=$data;
                        $this->load->model('Product_model');
                        $this->product_model->update($pid,$data);

                        
                        
                     $f=1;

                }
                
                if (  $this->upload->do_upload('rightview'))
                {
                        
                        $imgdetails = array('upload_data' => $this->upload->data());
                        $rightview=$this->upload->data('file_name');

                         $rightview=$rightview['file_name'];
                        $data=array("view"=>"rightview","img"=>$rightview,"pid"=>$pid);
                        
                        $this->load->model('Product_model');
                        $this->product_model->addsideview($data);
                }
               
                if (  $this->upload->do_upload('leftview'))
                {
                    
                        $imgdetails = array('upload_data' => $this->upload->data());
                        $leftview=$this->upload->data('file_name');

                         $leftview=$leftview['file_name'];
                        $data=array("view"=>"leftview","img"=>$leftview,"pid"=>$pid);
                        
                        $this->load->model('Product_model');
                        $this->product_model->addsideview($data);
                }
               
                if (  $this->upload->do_upload('topview'))
                {
                    
                        $imgdetails = array('upload_data' => $this->upload->data());
                        $topview=$this->upload->data('file_name');

                         $topview=$topview['file_name'];
                        $data=array("view"=>"topview","img"=>$topview,"pid"=>$pid);
                        
                        $this->load->model('Product_model');
                        $this->product_model->addsideview($data);
                }
                
                if (  $this->upload->do_upload('bottomview'))
                {
                    
                        $imgdetails = array('upload_data' => $this->upload->data());
                        $bottomview=$this->upload->data('file_name');

                         $bottomview=$bottomview['file_name'];
                        $data=array("view"=>"bottomview","img"=>$bottomview,"pid"=>$pid);
                        
                        $this->load->model('Product_model');
                        $this->product_model->addsideview($data);

                }
                if($f==0)
                {
                        
                        
                       // $error = array('error' => $this->upload->display_errors());
                        $error=array("error"=>"You did not select a file to upload.");

                        $this->load->view('product_uploadunsuccess', $error);
                }
                else
                    $this->load->view('product_uploadsuccess',$d);
                //img upload end
                
                
                //img upload end
                
    }

    public function do_upload()
        {
                $pid=$this->input->post('pid');
                $p_name=$this->input->post('p_name');
                $status=$this->input->post('status');
                $discription=$this->input->post('discription');
                $category=$this->input->post('Category');
                $o_price=$this->input->post('o_price');
                $r_price=$this->input->post('r_price');
                $s_price=$this->input->post('s_price');
                $c_price=$this->input->post('c_price');
                $srp=$this->input->post('srp');
        
                $img="";




                $f=0;
                //img upload start
                $config['upload_path']          = './uploads/store';
                $config['allowed_types']        = 'gif|jpg|png|jpeg';
                //$config['max_size']             = 100;
                //$config['max_width']            = 1024;
                //$config['max_height']           = 768;

                $this->load->library('upload', $config);


                if (  $this->upload->do_upload('img'))
                {
                    
                        
                        $imgdetails = array('upload_data' => $this->upload->data());
                        $img=$this->upload->data('file_name'); 
                        $img=$img['file_name'];                         
                        $data=array('p_name' => $p_name,'status' => $status,'discription'=> $discription,'o_price'=>$o_price,'r_price'=>$r_price,'s_price'=>$s_price,'c_price'=>$c_price,'srp'=>$srp,'img'=>$img,'pid'=>$pid,'p_category'=>$category);
                       

                        $this->product_model->addproduct($data);
                        $d["data"]=$data;

                        
                        
                     $f=1;

                }
                
                if (  $this->upload->do_upload('rightview'))
                {
                        
                        $imgdetails = array('upload_data' => $this->upload->data());
                        $rightview=$this->upload->data('file_name');

                         $rightview=$rightview['file_name'];
                        $data=array("view"=>"rightview","img"=>$rightview,"pid"=>$pid);
                        
                        $this->load->model('Product_model');
                        $this->product_model->addsideview($data);
                }
               
                if (  $this->upload->do_upload('leftview'))
                {
                    
                        $imgdetails = array('upload_data' => $this->upload->data());
                        $leftview=$this->upload->data('file_name');

                         $leftview=$leftview['file_name'];
                        $data=array("view"=>"leftview","img"=>$leftview,"pid"=>$pid);
                        
                        $this->load->model('Product_model');
                        $this->product_model->addsideview($data);
                }
               
                if (  $this->upload->do_upload('topview'))
                {
                    
                        $imgdetails = array('upload_data' => $this->upload->data());
                        $topview=$this->upload->data('file_name');

                         $topview=$topview['file_name'];
                        $data=array("view"=>"topview","img"=>$topview,"pid"=>$pid);
                        
                        $this->load->model('Product_model');
                        $this->product_model->addsideview($data);
                }
                
                if (  $this->upload->do_upload('bottomview'))
                {
                    
                        $imgdetails = array('upload_data' => $this->upload->data());
                        $bottomview=$this->upload->data('file_name');

                         $bottomview=$bottomview['file_name'];
                        $data=array("view"=>"bottomview","img"=>$bottomview,"pid"=>$pid);
                        
                        $this->load->model('Product_model');
                        $this->product_model->addsideview($data);

                }
                if($f==0)
                {
                        
                        
                       // $error = array('error' => $this->upload->display_errors());
                        $error=array("error"=>"You did not select a file to upload.");

                        $this->load->view('product_uploadunsuccess', $error);
                }
                else
                    $this->load->view('product_uploadsuccess',$d);
                //img upload end
                
        }
    


    

}
?>
