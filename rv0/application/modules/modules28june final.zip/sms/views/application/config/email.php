<?php
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'mail.smtp2go.com';
$config['smtp_port'] = '2525'; // 8025, 587 and 25 can also be used. Use Port 465 for SSL.
$config['smtp_crypto'] = 'tls';
$config['smtp_user'] = 'ganesh.kanthiwar@gmail.com';
$config['smtp_pass'] = 'gani.123';
$config['charset'] = 'utf-8';
$config['mailtype'] = 'html';
$config['newline'] = "rn";
?>