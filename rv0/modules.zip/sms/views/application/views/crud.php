<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body>
<div align="center">
<form >
<table>
<tr><td><input type="button" name="create" value="create"></td><td><input type="button"  name="update" value="update"></td></tr>
<tr>
	<td>Username</td><td><input type="text" name="username" id="username"></td>
</tr>
<tr>
	<td>Email</td><td><input type="text" name="email" id="email"></td>
</tr>
<tr>
	<td>Country</td><td><input type="text" name="country" id="country"></td>
</tr>
<tr>
<td>Password</td><td><input type="password" name="pwd" id="pwd"></td>
</tr>
<tr>
<td>Confirm Password</td><td><input type="password" name="cpwd" name="cpwd"></td>
</tr>
<tr>
<td></td><td><input type="submit" value="Submit" name="Submit" ></td>
</tr>
</table>
</form>
</div>

</body>
</html>
