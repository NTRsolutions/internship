

<h3>Your file was not uploaded!</h3>
<?php echo $error;?>

<p><?php echo anchor('http://localhost/new/rv0/product/addproduct', 'Upload Another File!'); ?></p>

