<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body>
<div align="right">
<input type="submit" value="Sign in" name="signin" onclick="window.location='<?php echo site_url("sign_control/signin");?>'"> 
<input type="submit" value="Sign up" name="signup" onclick="window.location='<?php echo site_url("sign_control/signup");?>'">
</div>

</body>
</html>
