<?php 

class Drop_model extends CI_Model
{
	function __constuct()
	{
		parent::__constuct();
	}
	public function create1()
	{
		$this->db->select('class');
		$this->db->distinct();
		$res=$this->db->get('student_details');
		return $res->result();
    }

    public function section1($class)
	{
		$this->db->select('section');
		
		$this->db->where('class',$class);
		$res=$this->db->get('student_details');
		return $res->result();
    }
   
}
