c
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<style type="text/css">
	a{
		text-decoration: none;
		color: black;

	}
	a:focus {
    outline: none;
	}
	span
	{
		margin-left: 15px; 
	}
	a:hover span
	{
		background:#4682B4;
		border-radius:5px;
	}
	div
	{
		float:left;
		margin-left: 20px;
	}
</style>
</head>
<body>

<?php foreach($filenames as $key =>$value):?>
	<div>
<a href="<?php echo base_url("Files/open/").$value['relative_path'].$value['name'];?>" onclick="return false" ondblclick="location=this.href"><img onmouseover="this.src='<?php echo base_url("uploads/folder2.png");?>'" onmouseout="this.src='<?php echo base_url("uploads/folder1.png");?>'" src="<?php echo base_url("uploads/folder2.png");?>" height="100" width="100"><br><span>&nbsp;<?php echo $value['name'];?>&nbsp;</span></a>
</div>

<?php endforeach;?>
<div>
<a href="<?php echo base_url('Files/create_class/').'Files/';?>"><img onmouseover="this.src='<?php echo base_url("uploads/plus2.png");?>'" onmouseout="this.src='<?php echo base_url("uploads/plus1.png");?>'" src="<?php echo base_url("uploads/plus1.png");?>" height="120" width="110"></a>
</div>
</body>
</html>


