<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Drop_control extends CI_Controller
{
	
	public function index()
	{
		$this->load->view('drop_view');
	}
	public function create()
	{
		echo "hi";
		 $student=$this->input->post('student');
                 //echo  '<option value="">'.$student.'</option>';
                 // echo '<option value="class"selected="selected">Class</option>';
		 $this->load->model('drop_model');
		 $user=$this->drop_model->create1();
		 
		 
		 echo '<option value="" selected="selected">Select class</option>';
                 foreach($user as $c){

                 echo '<option value="'.$c->class.'">'.$c->class.'</option>';
              }

      
    
	}
	public function section()
	{
		 $class=$this->input->post('class');
                 //echo  '<option value="">'.$class.'</option>';
                 // echo '<option value="class"selected="selected">Class</option>';
		 $this->load->model('drop_model');
		 $usr=$this->drop_model->section1($class);
		
		echo "<option>hi</option><option>hii</option><option>hiii</option><option>hiii</option>";
		
		  
		 
      
    
	}
	
}
?>
