<html>
<head>
<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>

 <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.0.2/css/bootstrap.min.css">

  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>

  <script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.2/js/bootstrap.min.js"></script>
 
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>

  <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.0.3/js/bootstrap.min.js"></script>

  <script src="http://cdn.rawgit.com/davidstutz/bootstrap-multiselect/master/dist/js/bootstrap-multiselect.js" type="text/javascript"></script>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>


<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.0.2/css/bootstrap.min.css">

  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>

  <script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" type="text/css">
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
<script type="text/javascript">
  $(document).ready(function() {

  

  });
</script>


  </head>
 <script>
           $(document).ready(function(){
    $("#selectcsv").change(function(){
              //alert($(this).val()) 
              $.post("http://localhost/CodeIgniter-3.1.4/index.php/Drop_control/create",{student:$(this).val()},function(data){
                $("#cla").html(data);
        
    });
            });
  });

            </script>
  
          
      <script>
           $(document).ready(function(){
    $("#cla").change(function(){
              //alert($(this).val()) 
              $.post("http://localhost/CodeIgniter-3.1.4/index.php/Drop_control/section",{class:$(this).val()},function(data){
                $("#section").html(data);
                $('#section').multiselect();
                
        
    });
            });
  });

            </script>




<body>




<div id="mine" >
</div>

   


<table class="table table-bordered">

 <tr>
    <td><div align="center">Select CSV</div></td>
    <td><div align="center">:</div></td>
    <td>
      
       <select name="selectcsv" id="selectcsv" class="form control">
       <option value="" selected="selected" >Select option</option>
       <option value="AllStudents" >All Students</option>
       <option value="Select_Specfic_class">Select_Specfic_class</option>
       </select>
       
    </td>
 </tr>

    <tr>
    <td><div align="center">Class</div></td>
    <td><div align="center">:</div></td>
    <td>
        <select name="cla" id="cla" >
        <option selected="selected">Select Class</option>
        </select>
    </td>
    </tr>

    <tr>
    <td><div align="center">Section</div></td>
    <td><div align="center">:</div></td>
    <td>
        <select name="section" id="section"  multiple="multiple">
        <option >Select Section</option>
        <option >St Section</option>
      </select>
    </td>
    </tr> 

</table>


</body>

</html>
