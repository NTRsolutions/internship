
<div style="margin-top: 70px;">


					
                      <div class="col-sm-9 col-md-9 col-md-offset-1" style="margin-top:50px; ">
                      
                      <div class="row" style="margin-top:10px;background-color:#FFDAB9;border-radius: 20px;" >
                      <h1>&emsp;&emsp;&emsp;No products are added to your cart</h1><br>
                      </div>
                       
                    </div>
        <div class="col-md-2 col-sm-3" style="margin-top:2cm;">
   <div ><table>
      <tr> <td style="background-color:#707070;height:180px;width:200px;font-size:11px;" class="table-responsive" >
      <p class="rg" style="margin-left:20px;"><a href="<?php echo base_url('store/standard_products');?>">STANDARD PRODUCTS</a></p> <p class="rg" style="margin-left:20px;">INDIVIDUAL PRODUCTS</p>
      <p class="rg" style="margin-left:25px;" >Students</p><p class="rg" style="margin-left:25px;">Alumni</p>
      <p class="rg" style="margin-left:25px;">Faculty</p><p class="rg" style="margin-left:25px;">Sports</p><p class="rg" style="margin-left:25px;">Merchandise</p>
      <p class="rg" style="margin-left:25px;">Accessories</p></td></tr></table>
  </div>
</div>
         
</div>







