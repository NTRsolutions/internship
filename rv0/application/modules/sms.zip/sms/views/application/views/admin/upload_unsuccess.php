<html>
<head>
<title>Upload Form</title>
</head>
<body>

<h3>Your file was not uploaded!</h3>
<?php echo $error;?>

<p><?php echo anchor('http://localhost/CodeIgniter-3.1.4/signedin/addproduct', 'Upload Another File!'); ?></p>

</body>
</html>